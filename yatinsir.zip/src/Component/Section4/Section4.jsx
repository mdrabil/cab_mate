import React from 'react'

const Section4 = () => {
  return (
    <div>Section4</div>
  )
}

export default Section4