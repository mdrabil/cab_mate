import { useMediaQuery } from '@mui/material'
import React from 'react'

// import Header from '../Header/Header'

import Home from '../Home/Home'
// import Section2 from '../Section2/Section2'
// import Section3 from '../Section3/Section3'
// import Section4 from '../Section4/Section4'
// import Footer from '../Footer/Footer'
// import Header2 from '../Header2/Header2'
// import Faq from '../FAQ/Faq'


const Hero = () => {

// const ismobile= useMediaQuery("(max-width:600px)");

  return (
    <div 

    >

<Home/> 


    </div>
  )
}

export default Hero