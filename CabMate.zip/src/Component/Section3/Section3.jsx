import React from 'react'

const Section3 = () => {
  return (
    <div>Section3</div>
  )
}

export default Section3