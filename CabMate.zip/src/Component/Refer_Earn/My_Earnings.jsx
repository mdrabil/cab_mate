import React from 'react'

const My_Earnings = () => {
  return (
    <div>My_Earnings</div>
  )
}

export default My_Earnings