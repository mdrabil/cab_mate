import React from 'react'

const Refer_Earn = () => {
  return (
    <div>Refer_Earn</div>
  )
}

export default Refer_Earn