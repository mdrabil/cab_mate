import React from 'react'

const Section2 = () => {
  return (
    <div>Section2</div>
  )
}

export default Section2